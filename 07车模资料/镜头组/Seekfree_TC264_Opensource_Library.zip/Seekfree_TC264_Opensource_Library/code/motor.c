/*
���ߣ�Charon and ������С��Ƭ
       δ����Ȩ��ֹת��
 */



#include "sys.h"

PID motor_l;
PID motor_r;
//-------------------------------------------------------------------------------------------------------------------
// �������     ������
//-------------------------------------------------------------------------------------------------------------------
void PWM_motor(float motor_1,float motor_2)
{
    if(motor_1<=0)             //���1��ת
        {
           motor_1 = -motor_1;
           gpio_set_level(DIR_L, 0);                    // DIR����
           pwm_set_duty(PWM_L, motor_1);                // PWMռ�ձ�
        }
        else
        {

           gpio_set_level(DIR_L, 1 );    //���1����                            // DIR����͵�ƽ
           pwm_set_duty(PWM_L, motor_1);                // ����ռ�ձ�=motor_1/1000000
        }

        if(motor_2<=0)       //���2��ת
           {
              motor_2 = -motor_2;
              gpio_set_level(DIR_R, 0);                    // DIR����͵�ƽ
              pwm_set_duty(PWM_R, motor_2);                // ����ռ�ձ�
           }
           else             //���2��ת
           {

              gpio_set_level(DIR_R,1);                    // DIR����͵�ƽ
              pwm_set_duty(PWM_R, motor_2);                // ����ռ�ձ�
           }
}


float Motor_l_PID(float actual_val )
{
    motor_l_speed_choose();
    motor_l.pid_actual_val=actual_val;
    motor_l.pid_err=motor_l.pid_target_val-motor_l.pid_actual_val;

    motor_l.pid_out=motor_l.pid_Kp*(motor_l.pid_err-motor_l.pid_err_last) +
                    motor_l.pid_Ki*motor_l.pid_err +
                    motor_l.pid_Kd*(motor_l.pid_err-2*motor_l.pid_err_last+motor_l.pid_err_last_last);
    motor_l.pid_err_last_last=motor_l.pid_err_last;
    motor_l.pid_err_last=motor_l.pid_err;


    return   motor_l.pid_out;
}

float Motor_r_PID(float actual_val )
    {
    motor_r_speed_choose();
    motor_r.pid_actual_val=actual_val;
    motor_r.pid_err=motor_r.pid_target_val-motor_r.pid_actual_val;

    motor_r.pid_out=motor_r.pid_Kp*(motor_r.pid_err-motor_r.pid_err_last) +
                    motor_r.pid_Ki*motor_r.pid_err +
                    motor_r.pid_Kd*(motor_r.pid_err-2*motor_r.pid_err_last+motor_r.pid_err_last_last);
    motor_r.pid_err_last_last=motor_r.pid_err_last;
    motor_r.pid_err_last=motor_r.pid_err;

return   motor_r.pid_out;
    }


void Motor_l_PID_Init(void)
{
    motor_l.pid_actual_val=0;
    motor_l.pid_target_val=target_speed;
    motor_l.pid_err=0;
    motor_l.pid_err_last=0;
    motor_l.pid_err_last_last=0;
    motor_l.pid_lvbo_err_last=0;
    motor_l.pid_err_sum=0;
    motor_l.pid_Kp=50;       //50           //////65   //50    //50
    motor_l.pid_Ki=8;        //8           //////2.2   //2    //8
    motor_l.pid_Kd=60;       //60           //////70   //70    //60
    motor_l.pid_err_sum_min=-2000;
    motor_l.pid_err_sum_max=2000;
    motor_l.pid_end_min=-5000;
    motor_l.pid_end_max=5000;
}

void Motor_r_PID_Init(void)
{
    motor_r.pid_actual_val=0;
    motor_r.pid_target_val=target_speed;
    motor_r.pid_err=0;
    motor_r.pid_err_last=0;
    motor_r.pid_err_last_last=0;
    motor_r.pid_err_sum=0;
    motor_r.pid_Kp=50;       //50               ///// ///65    //50    //50
    motor_r.pid_Ki=8;        //8               ///// ///2.2    //2     //8
    motor_r.pid_Kd=60;       //60               /////// 70    //80    //60
    motor_r.pid_err_sum_min=-2000;
    motor_r.pid_err_sum_max=2000;
    motor_r.pid_end_min=-5000;
    motor_r.pid_end_max=5000;
}





//-------------------------------------------------------------------------------------------------------------------
// �������     �����ʼ��
//-------------------------------------------------------------------------------------------------------------------
void motor_init(void)
{
    gpio_init(DIR_R, GPO, GPIO_HIGH, GPO_PUSH_PULL);                            // GPIO ��ʼ��Ϊ��� Ĭ�����������
    pwm_init(PWM_R, 17000,0);                                                  // PWM ͨ����ʼ��Ƶ�� 17KHz ռ�ձȳ�ʼΪ 0

    gpio_init(DIR_L, GPO, GPIO_HIGH, GPO_PUSH_PULL);                            // GPIO ��ʼ��Ϊ��� Ĭ�����������
    pwm_init(PWM_L, 17000,0);

    Motor_l_PID_Init();
    Motor_r_PID_Init();
}


void ws_motor_init(void)
{

    pwm_init(WS_PWM_R, 50,0);                        // PWM ͨ����ʼ��Ƶ��50Hz ռ�ձȳ�ʼΪ 0
    pwm_init(WS_PWM_L, 50,0);
}

//����·��ѡ���ٶ�
void motor_l_speed_choose(void)
{
    if(xunxian==0||tingche_flag==1)
        {motor_l.pid_target_val=0;
        pwm_set_duty(WS_PWM_L,700);                // ����ռ�ձ�
        }

   else if(annulus_L_Flag==1||annulus_R_Flag==1)
        {
            motor_l.pid_target_val=annulus_speed-(float)piancha*0.2;
            pwm_set_duty(WS_PWM_L,700);
        }

   else if(bend_straight_flag==1)
   { motor_l.pid_target_val=bend_speed;
      pwm_set_duty(WS_PWM_L,700);

   }
   else if  (S_road_Flag==1)
     {
         motor_l.pid_target_val=S_speed;
         pwm_set_duty(WS_PWM_L,700);
     }

        else
        {motor_l.pid_target_val=target_speed-(float)piancha*0.25;
        pwm_set_duty(WS_PWM_L,700);
        }
//       motor_l.pid_target_val=100;

}

//����·��ѡ���ٶ�
void motor_r_speed_choose(void)
{
    if(xunxian==0||tingche_flag==1)
       {motor_r.pid_target_val=0;
       pwm_set_duty(WS_PWM_R,760);                // ����ռ�ձ�
       }
    else if(annulus_L_Flag==1||annulus_R_Flag==1)
         {
            motor_r.pid_target_val=annulus_speed+(float)piancha*0.2;
            pwm_set_duty(WS_PWM_R,760);
         }

    else if(bend_straight_flag==1)
           {motor_r.pid_target_val=bend_speed;
            pwm_set_duty(WS_PWM_R,760);
           }


    else if (S_road_Flag==1)
      {
          motor_r.pid_target_val=S_speed;
          pwm_set_duty(WS_PWM_R,760);
      }


       else
       { motor_r.pid_target_val=target_speed+(float)piancha*0.25;
         pwm_set_duty(WS_PWM_R,760);
       }
//   motor_r.pid_target_val=100;
}

