/*
���ߣ�Charon and ������С��Ƭ
       δ����Ȩ��ֹת��
 */


#ifndef CODE_SYS_H_
#define CODE_SYS_H_

#include "zf_common_headfile.h"
#include "motor.h"
#include "camera.h"
#include "encoder.h"
#include "servo.h"
#include "isr.h"
#include "cpu0_main.h"

float slope_calculate (uint8 begin, uint8 end,int * border);
void caculate_distance(uint8 start,uint8 end,int *border,float *slope_new,float *distance_new);




#endif /* CODE_SYS_H_ */
