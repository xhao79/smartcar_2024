#include "headfile.h"


uint8 pid_cchu[6]={0};              //pid�����洢����


//.......���к�����ʼ��.....//
void All_Init(void)
{
	Cotrl_Init();
	SpeedPID_Init();
	Turn_Init();
	ips114_init();
	imu660ra_init();
	Dianci_ADC_Init();
	wireless_uart_init();
	key_Init();
	Turn_n_Init();
	Beep_Init();
//	dl1a_init();      //tof��ʼ��
//	while(dl1a_init()){ips114_showstr(0,80,"error");}
	//	iap_init();                 //eeprom��ʼ��
}

//............�����ʼ��.........//
void Cotrl_Init(void)
{
	gpio_mode(P6_4,GPO_PP);
	pwm_init(PWM_1, 17000, 0);
	
	gpio_mode(P6_0,GPO_PP);
	pwm_init(PWM_2, 17000, 0);
	Encor_Init();      //��������ʼ��
	
}
void Beep_Init(void)
{
	gpio_mode(P7_7,GPO_PP);
}

//............��������ʼ��.......//
void Encor_Init(void)
{
	ctimer_count_init(CTIM0_P34);        //�ö�ʱ���������������
	ctimer_count_init(CTIM3_P04);
	
}

//.......�ٶ�����ʽpid��ʼ��....//
void SpeedPID_Init(void)
{
	Pid_Init(&Speed1pid);
	Pid_Init(&Speed2pid);	

	
	Speed1pid.kp           =  pid_canshu[0];
	Speed1pid.ki           =  pid_canshu[1];
	Speed1pid.kd           =  pid_canshu[2];
	Speed1pid.out_i_limit  =  pid_canshu[3];
	Speed1pid.output_limit =  pid_canshu[4];
	
	Speed2pid.kp           =  pid_canshu[0];
	Speed2pid.ki           =  pid_canshu[1];
	Speed2pid.kd           =  pid_canshu[2];
	Speed2pid.out_i_limit  =  pid_canshu[3];
	Speed2pid.output_limit =  pid_canshu[4];
}

//......ת���⻷��ʼ��.....//
void Turn_Init(void)
{
	Pid_Init(&turn_pid);
	
	turn_pid.kp            =  pid_turn_canshu[0];
	turn_pid.ki            =  pid_turn_canshu[1];
	turn_pid.kd            =  pid_turn_canshu[2];
	turn_pid.out_i_limit   =  pid_turn_canshu[3];
	turn_pid.output_limit  =  pid_turn_canshu[4];
}

//......ת���ڻ���ʼ��....//
void Turn_n_Init(void)
{
	Pid_Init(&turn_n_pid);
	
	turn_n_pid.kp            =  turn_n_pid_canshu[0];
	turn_n_pid.ki            =  turn_n_pid_canshu[1];
	turn_n_pid.kd            =  turn_n_pid_canshu[2];
	turn_n_pid.out_i_limit   =  turn_n_pid_canshu[3];
	turn_n_pid.output_limit  =  turn_n_pid_canshu[4];
}

//.......������ʼ��.....//
void key_Init(void)
{
	gpio_mode(P7_0,GPIO);
	gpio_mode(P7_1,GPIO);
	gpio_mode(P7_2,GPIO);
	gpio_mode(P7_3,GPIO);
	gpio_mode(P7_5,GPIO);
}

void isp_xshi(void)
{
	if(lp_jishu_flag==0)
	{
		ips114_showint16(0,0,adc_num[0]);     ips114_showint16(60,0,adc_guiyi_num[0]);   
		ips114_showint16(0,1,adc_num[1]);     ips114_showint16(60,1,adc_guiyi_num[1]);   
		ips114_showint16(0,2,adc_num[4]);     ips114_showint16(60,2,adc_guiyi_num[4]);   
		ips114_showint16(0,6,adc_num[2]);     ips114_showint16(60,6,adc_guiyi_num[2]);  
		ips114_showint16(0,4,adc_num[6]);     ips114_showint16(60,4,adc_guiyi_num[6]);   
		ips114_showint16(0,3,adc_num[5]);     ips114_showint16(60,3,adc_guiyi_num[5]);   
		ips114_showint16(0,7,adc_num[3]);     ips114_showint16(60,7,adc_guiyi_num[3]);   
		ips114_showint16(0,5,adc_num[7]);     ips114_showint16(60,5,adc_guiyi_num[7]);
//		ips114_showint16(0,6,adc_num[9]);     ips114_showint16(60,6,adc_guiyi_num[9]);
//		ips114_showint16(0,5,imu660ra_gyro_transition(imu660ra_gyro_y));   //ips114_showint16(60,4,chabih);   
//		ips114_showfloat(0,5,imu660ra_gyro_transition(imu660ra_gyro_y),3,4);  ips114_showfloat(60,5,gyro_z,3,4); 
	}
	else if(lp_jishu_flag==1)
	{
		ips114_clear(YELLOW);
	}

}