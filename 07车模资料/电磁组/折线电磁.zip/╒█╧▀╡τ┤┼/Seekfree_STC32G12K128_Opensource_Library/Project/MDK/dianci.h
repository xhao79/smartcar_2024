#ifndef __DIANCI_H__
#define __DIANCI_H__

#include "headfile.h"

extern uint16 adc_num[10];
extern int16 adc_guiyi_num[10];
extern int16 dianchi_adc;

void Dianci_ADC_Init(void);
uint16 Dianci_average(ADCN_enum adcn,ADCRES_enum ch,uint8 N);
void Dianci_Num(void);
void Dianci_Guiyi(void);
float Dianci_cbh(int16 a_num,int16 b_num,int16 bshu);
void dianchi_jc(void);

#endif