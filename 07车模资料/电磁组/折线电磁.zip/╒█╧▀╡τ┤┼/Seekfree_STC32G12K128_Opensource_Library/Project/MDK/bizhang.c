#include "headfile.h"


uint8 bizhang_flag=0;
uint8 bz_flag=0;

//........��⵽�ϰ�........//
void bizhang_first(void)
{
	if(dl1a_distance_mm<500)
	{
		bizhang_flag=1;
	}
		
}
//........��⵽�ϰ�֮��Ĵ�����ʽ........//
void bizhang_sud_deal(void)
{
	if(bizhang_flag==1)
	{
		Angle_Target=0;
		if(bz_flag==0)
		{
			Targetspeed[0]=2*Targetspeed[0];
		}
		
		
	}
}