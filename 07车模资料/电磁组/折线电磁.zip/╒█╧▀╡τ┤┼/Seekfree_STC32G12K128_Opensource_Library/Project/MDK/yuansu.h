#ifndef __YUANSU_H__
#define __YUANSU_H__

#include "headfile.h"

extern uint8 cricle_flag1[3];
extern uint8 yuansu_flag;

void pand_yuamsu(void);
void podao_pd(void);
void shiz_pd(void);
void Cricle_pd(void);
void zhijiao_pd(void);


#endif