#ifndef __INIT_H__
#define __INIT_H__

#include "headfile.h"

#define key1    P70
#define key2    P71
#define key3    P72
#define key4    P73
#define boma    P75
#define Beep    P77



extern uint8 pid_cchu[6];


void Cotrl_Init(void);
void Encor_Init(void);
void SpeedPID_Init(void);
void Turn_Init(void);
void Turn_n_Init(void);
void All_Init(void);
void key_Init(void);
void Beep_Init(void);
void isp_xshi(void);

#endif