#ifndef __ANGLE_H__
#define __ANGLE_H__


#include "headfile.h"

extern float Icm_Value;
extern float gyro_z;
extern float gyro_z_lp;
extern uint8 lp_jishu_flag;
extern float Encor_jf_num;


void ICM_jifen(void);
float fabs(float num);
void ICM_getnum(void);
void Encor_jifen(void);


#endif