#ifndef  __BIZHANG_H__
#define  __BIZHANG_H__

#include "headfile.h"

extern uint8 bizhang_flag;



void bizhang_first(void);

#endif