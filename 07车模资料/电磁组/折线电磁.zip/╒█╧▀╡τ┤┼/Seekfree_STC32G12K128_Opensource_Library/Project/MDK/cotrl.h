#ifndef __COTRL_H__
#define __COTRL_H__


#include "headfile.h"

#define DIR_1 P64
#define DIR_2 P60
#define PWM_1 PWMA_CH4P_P66
#define PWM_2 PWMA_CH2P_P62
#define EncorL    CTIM0_P34
#define EncorR    CTIM3_P04
#define DIR_L     P35
#define DIR_R     P53

extern int16 Encor[2];
extern int16 Targetspeed[2];
extern int16 EndSpeed[2];
extern float pid_canshu[3];
extern float pid_turn_canshu[5];
extern float turn_n_pid_canshu[5];
extern float Angle_Target;
extern uint8 speed_ctrl_flag;
extern uint8 phualb_flag;
extern int16 shur[2];
extern int16 turn_error;


void Cotrl_pwm(int16 duty1,int16 duty2);
void Encor_Get(void);
void Motor_Pid_Ctrl(void);
void Motor_turn_Ctrl(void);
float Turn_n_cotrl(int16 num);
float Turn_cotrl(int16 num1,int16 num2);
void Uart_Sendnum(int a,int b,int c,int d,int e,int f,int g);
void eeprom_cchu_pid(void);
void yuansu_deal(void);
void speed_ctrl(void);
void speed_phua_lb(float lb_speed0,float lb_speed1);
uint16 Encor_lvbo(uint16 shur,float num);


#endif