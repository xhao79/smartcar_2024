#include "headfile.h"

uint8 flag0[2]={0};   //�µ���־λ 0Ϊ�ж��µ���־λ  1Ϊ���µ���־λ
uint8 flag_shizi[1]={0};  //ʮ�ֱ�־λ 0Ϊ�ж�ʮ�ֱ�־λ  1Ϊ��ʮ�ֱ�־λ
uint8 flag_zhijiao=0;  //ֱ�Ǳ�־λ 0Ϊ�ж�ֱ�Ǳ�־λ  1Ϊ��ֱ�Ǳ�־λ
uint8 cricle_flag1[3]={0};   //����Բ����־λ  0ΪԤ�����뻷��־λ
														//1Ϊ���뻷��־λ  2Ϊ�Ƿ���Բ���ڱ�־λ
uint8 yuansu_flag=1;     //��Ԫ�ر�־λ
//1Ϊ������2ΪԲ����3Ϊ�µ�  4Ϊֱ�� 5Ϊʮ��
void pand_yuamsu(void)
{
	Cricle_pd();
	podao_pd();
	shiz_pd();
	zhijiao_pd();
}   


//..........�ж��µ�.....//
void podao_pd(void)
{
		if(adc_guiyi_num[6]>160&&((adc_guiyi_num[0]<100)&&((adc_guiyi_num[1]<100)))&&flag0[0]==0&&yuansu_flag==1)  //��⵽�µ�
		{
			flag0[0]=1;
			flag0[1]=1;
		}


		if(adc_guiyi_num[6]>100&&flag0[0]==2)  //���׼���뿪�µ�
		{
			flag0[0]=3;
		}
		if(flag0[0]==3&&adc_guiyi_num[6]<10)
		{
			flag0[0]=0;
			flag0[1]=0;			
		}
		if(flag0[1]==1&&adc_guiyi_num[6]<10)  //���µ�ʱ����
		{
			Beep=1;
			flag0[0]=2;   //��ֹ���г��µ�
			yuansu_flag=3;
			speed_ctrl_flag=4;
		}
		else if(flag0[0]==0&&yuansu_flag==3)
		{
			Beep=0;
			speed_ctrl_flag=1;	
			yuansu_flag=1;
		}
		
}


//........Բ���ж�........//
void Cricle_pd(void)
{
	if(cricle_flag1[0]==0&&(adc_guiyi_num[6]>30)&&(adc_guiyi_num[1]>150&&adc_guiyi_num[0]>150)&&yuansu_flag==1)    //׼���뻷
	{
		cricle_flag1[0]=1;     //׼���뻷
		yuansu_flag=2;
		
	}
	//�뻷�ж�
	if(cricle_flag1[0]==1&&(adc_guiyi_num[7]>80))
	{
		cricle_flag1[1]=1;    //���������뻷��
	}
	
	if(cricle_flag1[1]==1&&(adc_guiyi_num[6]<10&&adc_guiyi_num[7]<10))  //�ڻ����ж�
	{
		speed_ctrl_flag=3;    //�����ٶ�
		cricle_flag1[2]=1;    //��ʾ�Ѿ����뻷
	}
	//׼������
	if(cricle_flag1[2]==1&&adc_guiyi_num[7]>30) 
	{
		cricle_flag1[2]=2;
	}
	if(cricle_flag1[2]==2&&(adc_guiyi_num[7]<20))
	{
		cricle_flag1[0]=0;
		cricle_flag1[1]=0;
		cricle_flag1[2]=0;
		yuansu_flag=1;
	}
	if(cricle_flag1[0]==1)
	{
		Beep=1;
		speed_ctrl_flag=2;      //�뻷�ٶ�
	}
	if(cricle_flag1[0]==0)
	{
		Beep=0;
		speed_ctrl_flag=1;
	}
	
}


//........ʮ���ж�.......//
void shiz_pd(void)
{
	if(flag_shizi[0]==0&&(adc_guiyi_num[4]>120)&&(adc_guiyi_num[5]>120)&&yuansu_flag==1)    //ʮ�ּ��
	{
		flag_shizi[0]=1;
	}
	if(flag_shizi[0]==1&&(adc_guiyi_num[4]<10&&adc_guiyi_num[5]<10))          //�Ѿ�����ʮ��
	{
		flag_shizi[0]=2;
	}
	if(flag_shizi[0]==2&&(adc_guiyi_num[4]>100&&adc_guiyi_num[5]>100))     //��ʮ��
	{
		flag_shizi[0]=3;    //�����Ѿ���Ԫ��
	}
	if(flag_shizi[0]==2)
	{
		Beep=1;
		yuansu_flag=5;
		speed_ctrl_flag=6;
	}
	else if(flag_shizi[0]==3&&(adc_guiyi_num[4]<20&&adc_guiyi_num[5]<20)&&yuansu_flag==5)
	{
		Beep=0;
		flag_shizi[0]=0;
		speed_ctrl_flag=1;
		yuansu_flag=1;
	}
}


//ֱ���ж�
void zhijiao_pd(void)
{
	if(yuansu_flag==1&&flag_zhijiao==0&&(adc_guiyi_num[0]<90&&adc_guiyi_num[1]<90)&&((adc_guiyi_num[4]-adc_guiyi_num[5]>60)||(adc_guiyi_num[5]-adc_guiyi_num[4]>60)))
	{
		flag_zhijiao=1;
		
	}
	if(flag_zhijiao==1)  //��ֱ��
	{
		Beep=1;
		speed_ctrl_flag=5;
		yuansu_flag=4;
	}
	if(flag_zhijiao==1&&adc_guiyi_num[0]>80&&adc_guiyi_num[1]>80)
	{
		flag_zhijiao=0;
		
	}
	if(flag_zhijiao==0&&yuansu_flag==4)    //��ֱ��
	{
		Beep=0;
		speed_ctrl_flag=1;
		yuansu_flag=1;
	}
}



//........Բ����һ���뻷��׼ȷ�޷���ȷ���뻷....//
//	//......���뻷....//
//	if((adc_guiyi_num[0]>190)&&(adc_guiyi_num[1]>160)&&(adc_guiyi_num[2]>120)&&(adc_guiyi_num[3]>140)&&cricle_flag[0]==0)
//	{
//		cricle_zy_flag=1;
//		cricle_flag[0]=1;
//		cricle_flag[1]=1;
//		cricle_flag1=1;
//	}

//	if((adc_guiyi_num[0]>180)&&(adc_guiyi_num[1]<140)&&(adc_guiyi_num[2]>140)&&(50<adc_guiyi_num[3]<80)&&cricle_flag[0]==1)
//	{
//		cricle_flag[0]=0;
//		cricle_flag[1]=2;
//	}
//	if(cricle_flag[1]==1)
//	{
//		flag01[2]=1;
//	}
//	else if(cricle_flag[1]==2)
//	{
//		cricle_flag[1]=0;
//		flag01[2]=0;
//		
//	}
//	//......���뻷......//
//	if((adc_guiyi_num[0]>160)&&(adc_guiyi_num[1]>190)&&(adc_guiyi_num[2]>90)&&(adc_guiyi_num[3]>140)&&cricle_flag[2]==0)
//	{
//		cricle_zy_flag=2;
//		cricle_flag[2]=1;
//		cricle_flag[3]=1;
//		cricle_flag1=1;
//	}
//	if((adc_guiyi_num[0]>190)&&(adc_guiyi_num[1]>160)&&(adc_guiyi_num[2]<60)&&(adc_guiyi_num[3]>160)&&cricle_flag[2]==1)
//	{
//		cricle_flag[2]=0;
//		cricle_flag[3]=2;
//	}
//	if(cricle_flag[3]==1)
//	{
//		flag01[2]=1;
//	}
//	else if(cricle_flag[3]==2)
//	{
//		cricle_flag[2]=0;
//		flag01[2]=0;
//		
//	}



//......��һ���Ӧ���뻷����.......//
//		if(flag01[2]==1)
//		{
//			Beep=1;
////			if(120<adc_guiyi_num[2]<140&&120<adc_guiyi_num[3]<140)
////			{
////				Angle_Target=Turn_cotrl(adc_guiyi_num[2],adc_guiyi_num[3]);
////			}
////			else
////			{
//			if(cricle_zy_flag==1)
//			{
//				Angle_Target=Turn_cotrl(0.8*adc_guiyi_num[2]+1.8*adc_guiyi_num[0],0.8*adc_guiyi_num[1]+1.8*adc_guiyi_num[3]);
//			}
//			if(cricle_zy_flag==2)
//			{
//				Angle_Target=Turn_cotrl(1.8*adc_guiyi_num[2]+0.8*adc_guiyi_num[0],1.8*adc_guiyi_num[1]+0.8*adc_guiyi_num[3]);
//			}
//				
////			}
//			
//		}
//		else if(flag01[2]==0)
//		{
//			Beep=0;
////			if(adc_guiyi_num[2]<180&&adc_guiyi_num[3]<60)
////			{
//				Angle_Target=-Turn_cotrl(2*adc_guiyi_num[2]+adc_guiyi_num[0],2*adc_guiyi_num[3]+adc_guiyi_num[1]);
////			}
//			if((adc_guiyi_num[2]<100&&adc_guiyi_num[3]<30))
//			{
//				cricle_flag1=0;
//			}



/*
�ڶ���
	if(adc_guiyi_num[6]>140&&(adc_guiyi_num[4]<70&&adc_guiyi_num[5]<70)&&(((adc_guiyi_num[3]>170&&(adc_guiyi_num[3]-adc_guiyi_num[2]>60))||((adc_guiyi_num[2]-adc_guiyi_num[3]>60)&&adc_guiyi_num[2]>170))||(adc_guiyi_num[3]>140&&adc_guiyi_num[2]>140))&&cricle_flag1[0]==0)
	{
		cricle_flag1[0]=1;
		
	}
	if(((adc_guiyi_num[4]>60&&adc_guiyi_num[5]>60)||((adc_guiyi_num[4]-adc_guiyi_num[5]>170)||(adc_guiyi_num[5]-adc_guiyi_num[4]>170)))&&((adc_guiyi_num[3]-adc_guiyi_num[2]>120)||(adc_guiyi_num[2]-adc_guiyi_num[3]>120)||(adc_guiyi_num[2]>90&&adc_guiyi_num[3]>90))&&cricle_flag1[0]==1)
	{
		cricle_flag1[0]=2;
	}
*/