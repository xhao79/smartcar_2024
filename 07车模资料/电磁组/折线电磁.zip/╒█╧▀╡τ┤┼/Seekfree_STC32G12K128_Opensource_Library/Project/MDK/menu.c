#include "headfile.h"


uint16 pidflag=1;          //ֻ����unsigned int���ͣ�������unsigned char����
uint16 flag=0,flag2=0;
uint8 beginflag=0;        //�����ʼ���б�־λ



void Menu_Pid(void)
{
	if(key1==0)
	{
		while(key1==0);
		flag++;
	}
	if(flag==1)
	{
		if(key2==0)
		{
			while(key2==0);
			pid_canshu[0]+=5;
			pid_canshu[3]+=5;
		}
		if(key3==0)
		{
			while(key3==0);
			pid_canshu[0]-=5;
			pid_canshu[3]-=5;
		}
		ips114_showstr(0,6,"kp");
	}
	if(flag==2)
	{
		if(key2==0)
		{
			while(key2==0);
			pid_canshu[1]+=1;
			pid_canshu[4]+=1;
		}
		if(key3==0)
		{
			while(key3==0);
			pid_canshu[1]-=1;
			pid_canshu[4]-=1;
		}
		ips114_showstr(0,6,"ki");
	}
	if(flag==3)
	{
		if(key2==0)
		{
			while(key2==0);
			pid_canshu[2]+=2;
			pid_canshu[5]+=2;
		}
		if(key3==0)
		{
			while(key3==0);
			pid_canshu[2]-=2;
			pid_canshu[5]-=2;
		}
		ips114_showstr(0,6,"kd");
		flag=0;
	}
ips114_showstr(0,5,"kd2:");            ips114_showint16(80,6,flag);
		
}













//........pid�˵�.......//
//void Menu_Pid(void)
//{
//	uint8 i;
//	for(i=0;i<6;i++)
//	{
//		pid_canshu[i]=pid_cchu[i];
//	}
//	ips114_showstr(0,0,"kp1:");            ips114_showint16(80,0,pid_canshu[0]);
//	ips114_showstr(0,1,"ki1:");            ips114_showint16(80,1,pid_canshu[1]);
//	ips114_showstr(0,2,"kd1:");            ips114_showint16(80,2,pid_canshu[2]);
//	ips114_showstr(0,3,"kp2:");            ips114_showint16(80,3,pid_canshu[3]);
//	ips114_showstr(0,4,"ki2:");            ips114_showint16(80,4,pid_canshu[4]);
//	ips114_showstr(0,5,"kd2:");            ips114_showint16(80,5,pid_canshu[5]);
//	ips114_showint16(0,6,flag1);           ips114_showint16(80,6,flag2);
//	if(key4==0)
//	{
//		while(key4==0);
//		beginflag=1;
//	}
//	if(key1==0)
//	{
//		while(key1==0);
//	}
//	if((pid_cchu[0]==255)&&(pid_cchu[1]==255)&&(pid_cchu[2]==255)&&(pid_cchu[3]==255)&&(pid_cchu[4]==255)&&(pid_cchu[5]==255))
//	{
//		iap_erase_page(0x06);
//	}
//	if(pidflag==1)
//	{
//		if(key2==0)
//		{
//			while(key2==0);
//			flag1++;
//		}
//			if(flag1==1)
//			{
//				if(key3==0)
//				{
//					while(key3==0);				
//					if(boma==1)
//					{
//					pid_cchu[0]=pid_canshu[0]+1;
//					pid_canshu[0]=pid_cchu[0];
//					}
//					else if(boma==0)
//					{
//					pid_cchu[0]=pid_canshu[0]-1;
//					pid_canshu[0]=pid_cchu[0];
//					}
//					iap_write_bytes(0x00,pid_cchu,6);
//				}
//			}else if(flag1==2)
//			{
//				if(key3==0)
//				{
//					while(key3==0);					
//					
//					if(boma==1)
//					{
//					pid_cchu[1]=1;
//					pid_canshu[1]+=pid_cchu[1];
//					}
//					else if(boma==0)
//					{
//					pid_cchu[1]=1;
//					pid_canshu[1]-=pid_cchu[1];
//					}
//					iap_write_bytes(0x00,pid_cchu,6);
//				}
//			}else if(flag1==3)
//			{
//				if(key3==0)
//				{
//					while(key3==0);				
//					
//					if(boma==1)
//					{
//					pid_cchu[2]=1;
//					pid_canshu[2]+=pid_cchu[2];
//					}
//					else if(boma==0)
//					{
//					pid_cchu[2]=1;
//					pid_canshu[2]-=pid_cchu[2];
//					}
//					iap_write_bytes(0x00,pid_cchu,6);
//				}
//				flag1=0;
//			}
//	}
//	else if(pidflag==2)
//	{
//		if(key2==0)
//		{
//			while(key2==0);
//			flag2++;
//		}
//			if(flag2==1)
//			{
//				if(key3==0)
//				{
//					while(key3==0);								
//					if(boma==1)
//					{
//					pid_cchu[3]=pid_canshu[3]+1;
//					pid_canshu[3]=pid_cchu[3];
//					}
//					else if(boma==0)
//					{
//					pid_cchu[3]=pid_canshu[3]-1;
//					pid_canshu[3]=pid_cchu[3];
//					}
//					iap_write_bytes(0x00,pid_cchu,6);
//				}
//			}else if(flag2==2)
//			{
//				if(key3==0)
//				{
//					while(key3==0);					
//				
//					if(boma==1)
//					{
//					pid_cchu[4]=1;
//					pid_canshu[4]+=pid_cchu[4]*0.1;
//					}
//					else if(boma==0)
//					{
//					pid_cchu[4]=1;
//					pid_canshu[4]-=pid_cchu[4]*0.1;
//					}
//					iap_write_bytes(0x00,pid_cchu,6);
//				}
//			}else if(flag2==3)
//			{
//				if(key3==0)
//				{
//					while(key3==0);					
//					
//					if(boma==1)
//					{
//					pid_cchu[5]=1;
//					pid_canshu[5]+=pid_cchu[5];
//					}
//					else if(boma==0)
//					{
//					pid_cchu[5]=1;
//					pid_canshu[5]-=pid_cchu[5];
//					}
//					iap_write_bytes(0x00,pid_cchu,6);
//				}
//				flag2=0;
//			}
//			pidflag=0;
//	}
//	iap_write_bytes(0x00,pid_cchu,6);
//}



