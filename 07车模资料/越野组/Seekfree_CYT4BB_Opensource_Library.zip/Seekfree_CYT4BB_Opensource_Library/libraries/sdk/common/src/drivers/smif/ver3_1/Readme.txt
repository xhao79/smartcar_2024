
V3_1 C2D4M, CE4M rev_a.

V3_1 represents SMIF_3_0

