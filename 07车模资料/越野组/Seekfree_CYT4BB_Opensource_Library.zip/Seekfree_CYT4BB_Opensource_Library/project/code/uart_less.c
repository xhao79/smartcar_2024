#include "uart_less.h"


#include "zf_common_headfile.h"


 uint8 dat;
 int num=0;
 uint32 ReadBuff0[512];
uint32 uart_flag;

void uart_read()
{
  //  dat = uart_read_byte(UART_1);  
  uart_query_byte(UART_1, &dat);    //�ű괮�� 
   if(dat==0x66)  
   {
     num=0;
     
   }
   else if(dat==0x88)
   {
     num=3;
   }
   ReadBuff0[num]=dat;
   if(num==3)
   {
     num=0;
     if(ReadBuff0[0]==0x66&&ReadBuff0[3]==0x88)
     
   {
     if(ReadBuff0[2]==(ReadBuff0[1]^0xff))
     {
       uart_flag=ReadBuff0[1];
     }
     
   }
   
   }
   else
   {
     num++;
   }
    
}