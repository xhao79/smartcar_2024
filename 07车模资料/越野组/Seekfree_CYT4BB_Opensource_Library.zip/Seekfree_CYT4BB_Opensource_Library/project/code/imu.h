
#ifndef _imu_h_
#define _imu_h_
#include "zf_common_headfile.h"


extern int IMU_set_flag,yaw_flag;//������־λ
extern float yaw;  //ƫ����
extern float last_yaw[61] ; //��ʷ�����
extern int8 icm_yaw_mark;
extern int8 last_yaw_mark;
typedef struct
{
 float gyroxdate;
 float gyroydate;
 float gyrozdate;
}gyrodate;

typedef struct
{
 float gyro_x;
 float gyro_y;
 float gyro_z;
 float acc_x;
 float acc_y;
 float acc_z;
}imudate;

float IMU_set();//��Ʈ����
void IMU_init();//��ʼ��
void  IMU_Z_360();
void IMU_integral();
void IMU_value();


//��Ԫ��
typedef struct{ 
    float q0;
    float q1;
    float q2;
    float q3;
}quaterInfo_t;

typedef struct{ 
    float pitch;
    float roll;
    float yaw;
}eulerianAngles_t;

typedef struct 
{
    int16 x;
    int16 y;
    int16 z;
}GyroOffset;

extern int Quaternions_falg;
extern float values[6];
extern float cycle[20];
extern int x;
extern eulerianAngles_t eulerAngle;

void GyroOffsetInit(void);
void IMUGetValues(float * values);
void IMU_quaterToEulerianAngles(void);
void Quaternions(void);


#endif