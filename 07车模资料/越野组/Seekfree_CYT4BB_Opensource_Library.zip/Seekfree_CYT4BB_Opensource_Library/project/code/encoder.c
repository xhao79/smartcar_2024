#include "encoder.h"

#include "zf_common_headfile.h"

int KP = 110;
int KI = 45;
int KD = 3;
int PWM_OUT = 0;//����ٶ�
int speed_encoder = 0;//������


void encoder_init(){

 encoder_dir_init(TC_CH07_ENCODER, TC_CH58_ENCODER_CH1_P17_3, TC_CH58_ENCODER_CH2_P17_4);//������л�
}
int Motor_PID_Cal(int input_speed,int setspeed)
{
  static int pwmout=0,last_error=0,last_last_error=0;
  int error =setspeed - input_speed;
  int d_error=error-last_error;
  int dd_error = -2*last_error+error+last_last_error;  
  pwmout+=KP*d_error/10 +KI*error/10+KD*dd_error/10;
  last_last_error=last_error;
  last_error = error;
	if(pwmout > 1000) pwmout = 1000;
	if(pwmout < -1000) pwmout = -1000;
  return pwmout;
}