#ifndef _control_h_
#define _control_h_
#include "zf_common_headfile.h"

void control_move();

extern int control_flag;





#endif