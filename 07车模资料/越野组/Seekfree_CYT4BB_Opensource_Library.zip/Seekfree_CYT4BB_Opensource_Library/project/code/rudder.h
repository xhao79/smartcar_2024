#ifndef _rudder_h_
#define _rudder_h_
#include "zf_common_headfile.h"









extern float value;
void rudder_init();
void set_dir (int dir);
float GPS_control(float Dir);


#endif