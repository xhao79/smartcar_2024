#ifndef _gps_h_
#define _gps_h_
#include "zf_common_headfile.h"




float GPS_get();
void GPS_init();
void GPS_count();
void my_flash_read(void);
void my_flash_write(void);
void gather();
extern int GPS_flag;
extern double distance,distance2,azimuth,yaw_actual;
extern double lat_store[30],lon_store[30];//�洢��γ��
extern double lo[60],la[60];
extern double a,b;//�ݴ澭γ��
extern int GPS_flag,point,point1,goal;


#endif