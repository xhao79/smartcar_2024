#ifndef _uart_less_h_
#define _uart_less_h_
#include "zf_common_headfile.h"

extern uint8 dat;
extern int num;
extern uint32 ReadBuff0[512];
extern uint32 uart_flag;
void uart_read();

#endif
