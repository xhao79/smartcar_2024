#ifndef _pwm_h_
#define _pwm_h_
#include "zf_common_headfile.h"



 extern int speed;
extern int voice_flag;
extern int gps_flag,goal_last;
 void PWM_init();
 void set_speed (int speed);
 void speed_voice_out();
 void speed_voice_internal();
 void speed_gps();
#endif
 