#include "control.h"

#include "zf_common_headfile.h"
#define DIR_CH1             (P10_3)                                            // �����������˿�
#define PWM_CH1             (TCPWM_CH30_P10_2)                                 // PWM����˿�
float nowvoice_angle;
int control_flag=0;

void control_move()//��������
{
  switch(control_flag)
     {
     case 1:
       {
         ips200_show_string(80,220,"*");
         ips200_show_string(80,240," ");
         ips200_show_string(80,260," ");
       
      }break;
      case 2:
       {
         ips200_show_string(80,220," ");
         ips200_show_string(80,240,"*");
       ips200_show_string(80,260," ");
        
       }break;
       case 3:
       {
         ips200_show_string(80,220," ");
         ips200_show_string(80,240," ");
         ips200_show_string(80,260,"*");
        
      }
     
       
    } 
  
  if(control_flag==1)//����
  {
    
    toda1();
	 nowvoice_angle = VoiceAngle;
   if(nowvoice_angle > 180) nowvoice_angle = nowvoice_angle - 360;
   if(nowvoice_angle <-180) nowvoice_angle = nowvoice_angle + 360;
   if(nowvoice_angle == 180) nowvoice_angle = 180;
   if(nowvoice_angle == -180) nowvoice_angle = 180;
	if(goal>0)
	{
        //speed_voice_internal();  
		set_dir(3*-nowvoice_angle); 
        pwm_set_duty(PWM_CH1, 1000); 
        gpio_set_level(DIR_CH1,GPIO_HIGH); 
    }
   else
	   {
		 pwm_set_duty(PWM_CH1, 0);                 
   		gpio_set_level(DIR_CH1, GPIO_HIGH);
	   }
    ips200_show_string(0, 220, "internal");
  }
  
  if(control_flag==2)//����
  {
    if(goal>0&&goal<3)    //�յ�����ϵͳָ��Ż�����
		{
  if(distance>3)   //�����Լ��л�
    {
     speed_gps();//gps����
   }
    else if(distance<3){
             
		//pwm_set_duty(PWM_CH1, 0); 
        //gpio_set_level(DIR_CH1,GPIO_HIGH);
		
		toda1();  //�Ƕȼ���
        
		 nowvoice_angle = VoiceAngle;
    if(nowvoice_angle > 180) nowvoice_angle = nowvoice_angle - 360;
    if(nowvoice_angle <-180) nowvoice_angle = nowvoice_angle + 360;
    if(nowvoice_angle == 180) nowvoice_angle = 180; 
    if(nowvoice_angle == -180) nowvoice_angle = 180;
   
	if(goal>0&&goal<3)    //�յ�����ϵͳָ��Ż�����
    {
	 
		if (nowvoice_angle <= 90 && nowvoice_angle >= -90)
    {
       set_dir(3*-nowvoice_angle);
        pwm_set_duty(PWM_CH1, 800); 
        gpio_set_level(DIR_CH1,GPIO_HIGH);
    }
   //if (nowvoice_angle > 90 && nowvoice_angle < 180)
    //{
       //set_dir(3*nowvoice_angle);
      // pwm_set_duty(PWM_CH1, 700); 
        //gpio_set_level(DIR_CH1,GPIO_LOW); 
   //}
    //if (nowvoice_angle >= -180 && nowvoice_angle < -90)
   //{
       //set_dir(3*nowvoice_angle);
      //pwm_set_duty(PWM_CH1, 700); 
       //gpio_set_level(DIR_CH1,GPIO_LOW); 
   // }
      }else{pwm_set_duty(PWM_CH1, 0);                 
   gpio_set_level(DIR_CH1, 1);}
	}
  }else{pwm_set_duty(PWM_CH1, 0);                 
   gpio_set_level(DIR_CH1, 1);}
	ips200_show_string(0, 240, "out");
  
  }
  if(control_flag==3)
  {
   ips200_show_string(0, 260, "delay"); 
   		pwm_set_duty(PWM_CH1, 1200); 
        gpio_set_level(DIR_CH1,1); //�����ֵ
  }
  
  //��Ļ��ʾ
 // tft180_show_string(0, 0, "direrror");tft180_show_float (60,0,direct_error,3,3);
 // tft180_show_string(0, 10, "g_Angle");tft180_show_float (60,10,g_Angle,3,3);
   ips200_show_string(0, 20, "la[point1]");  ips200_show_float(80, 20,la[point1], 3, 6);
  ips200_show_string(0, 40, "point");  ips200_show_float(80, 40,point,3,6);
  ips200_show_string(0, 60, "yaw");ips200_show_float (80,60, eulerAngle.yaw,4,5);
  ips200_show_string(0, 80, "distance"); ips200_show_float (80,80, distance,3,3);
  ips200_show_string(0, 100, "point1"); ips200_show_float(80, 100,point1,3,3);
  ips200_show_string(0, 120, "goal");ips200_show_int(80, 120,goal,2);
                                    ips200_show_int(80, 140,control_flag,2);
  
  ips200_show_int(80, 160,goal_last,4);
  ips200_show_int(80, 180,icm20602_acc_y,4);
  ips200_show_int(80, 200,icm20602_acc_z,4);;
  
  
    key_scanner();//����״̬ɨ��
key_get();//��������
  
}