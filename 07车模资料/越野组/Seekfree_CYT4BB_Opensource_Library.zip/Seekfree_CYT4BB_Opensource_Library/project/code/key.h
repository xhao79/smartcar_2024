#ifndef _key_h_
#define _key_h_
#include "zf_common_headfile.h"






void keyinit();
void key_get();





#endif