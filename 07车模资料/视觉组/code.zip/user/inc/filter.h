#ifndef _filter_h
#define _filter_h

/* �˲����ṹ�� */
#define M_2PI 6.283185307179586
typedef struct
{
		float sample_freq; //�����ź�Ƶ��
		float cutoff_freq; //��ֹƵ��
		float alpha; //ϵ��
		float oupt; //��ͨ�˲������		
}filter_t;

extern filter_t filter_gyro;
//extern filter_t filter_encoder1;
//extern filter_t filter_encoder2;
//extern filter_t filter_encoder3;
//extern filter_t filter_encoder4;
extern filter_t filter_X;
extern filter_t filter_Y;
extern filter_t filter_pwm1;
extern filter_t filter_pwm2;
extern filter_t filter_pwm3;
extern filter_t filter_pwm4;

float constrain_float(float amt, float low, float high);
void LowPassFilter_Init(filter_t *filter, float sample_freq, float cutoff_freq);
float LowPassFilter_apply(filter_t *filter, float sample);

#endif
