#ifndef __draw_image_H
#define __draw_image_H
#include "all_headfiles.h"
void draw_line_for_cross(uint8 pst[120][188],int x1,int x2,int y1,int y2);
void draw_image1(uint8 image[120][188]);
#endif