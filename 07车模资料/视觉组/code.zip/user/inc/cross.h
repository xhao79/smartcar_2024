#ifndef __cross_H
#define __cross_H
#include "all_headfiles.h"
int clip(int x,int low ,int up);

void nms_angle(float angle_in[], int num, float angle_out[], int kernel);

void local_angle_points(uint8 pts[][2],int pts_num,float angle_out[]);
int local_angle_points_l(uint8 pts1[][2],int pts_num1,float angle_out1[]);//������ҽǵ�
int local_angle_points_r(uint8 pts[][2],int pts_num,float angle_out[]);//�ұ����ҽǵ�
void find_down_left_and_right_corner(void);					//���������½ǵ㣬�ж����޽ǵ�
void myfind_corner(void);									//�ҵ��ҽǵ㣬Ϊ�˻�ȡ׼ȷ������
void judge_element(void);									//�ж�Ԫ�أ�num=1��Բ����num=2����ʮ��
void judge_element1(void);	
void judge_straight(void);                                  //�ж�ֱ��
void is_crossroad_element(void);
void is_circle_element(void);
void enter_crossroad(void);
void mytest_left_korner(uint16 pst[ipts0_num][2],uint8 pts0_num);
void mytest_right_korner(uint16 pst[ipts1_num][2],uint8 pst_num);
void work_loop(int tag);
void confirm_corner(void);

void judge_cross_or_circle1(void);
void judge_run_l_or_r_point(void);
void judge_run_l_or_r_k(void);
void judge_run_l_or_r_scan(void);
void judge_run_l_or_r_new(void);

void buxian_coss(void);
#endif