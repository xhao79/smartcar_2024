#ifndef __line_H
#define __line_H

void fine_line_corner();

#endif