#ifndef __pin_define_H
#define __pin_define_H


//--------------------------------------------------------------------
//����Ϊ���Ŷ���
//--------------------------------------------------------------------

//������Ŷ���
#define MAX_DUTY            	 (50 ) //���ռ�ձ�

#define MOTOR1_DIR               (C9 )
#define MOTOR1_PWM               (PWM2_MODULE1_CHA_C8)

#define MOTOR2_DIR               (C7 )
#define MOTOR2_PWM               (PWM2_MODULE0_CHA_C6)

#define MOTOR3_DIR               (D2 )
#define MOTOR3_PWM               (PWM2_MODULE3_CHB_D3)

#define MOTOR4_DIR               (C10 )
#define MOTOR4_PWM               (PWM2_MODULE2_CHB_C11)

//���������Ŷ���
#define ENCODER_1                       (QTIMER1_ENCODER1)
#define ENCODER_1_LSB                   (QTIMER1_ENCODER1_CH1_C0)
#define ENCODER_1_DIR                   (QTIMER1_ENCODER1_CH2_C1)
                                        
#define ENCODER_2                       (QTIMER1_ENCODER2)
#define ENCODER_2_LSB                   (QTIMER1_ENCODER2_CH1_C2)
#define ENCODER_2_DIR                   (QTIMER1_ENCODER2_CH2_C24)
                                        
#define ENCODER_3                       (QTIMER2_ENCODER1)
#define ENCODER_3_LSB                   (QTIMER2_ENCODER1_CH1_C3)
#define ENCODER_3_DIR                   (QTIMER2_ENCODER1_CH2_C4)
                                        
#define ENCODER_4                       (QTIMER2_ENCODER2)
#define ENCODER_4_LSB                   (QTIMER2_ENCODER2_CH1_C5)
#define ENCODER_4_DIR                   (QTIMER2_ENCODER2_CH2_C25)

//LED���Ŷ���
#define LED1                    (B9 )

//���������Ŷ���
#define BEEP                (B11)

//������Ŷ���
#endif