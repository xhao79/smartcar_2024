#include "all_headfiles.h"
//------------------------------------------------------------------------
//���²���Ϊ����
//------------------------------------------------------------------------

//����������
void buzzer_on(void)
{
	if(count_beep)
        {
            gpio_set_level(BEEP, GPIO_HIGH);
            count_beep --;
        }
        else
        {
            gpio_set_level(BEEP, GPIO_LOW);
        }
        
        system_delay_ms(5);	
}
//��һ����������
void key1_control_speed(void)
{
	key_scanner();
	if( KEY_SHORT_PRESS == key_get_state(KEY_1))
	{
		count_beep=5;
//		key_control_speed=1;

		key_clear_state(KEY_1);
	}
}
//�ڶ�����������
void key2_control_speed(void)
{
	key_scanner();
	if( KEY_SHORT_PRESS == key_get_state(KEY_2))
	{
		count_beep=5;
		key_control_speed=2;
		key_clear_state(KEY_2);
	}
}
//ɨ�谴��
void scan_keyboard(void)
{
	key_scanner();
	if(KEY_SHORT_PRESS == key_get_state(KEY_1))
	{
		count_beep=5;	
		//key_control_speed=1;
		button1_tag=1;

		key_clear_state(KEY_1);			
	}
	else if(KEY_SHORT_PRESS == key_get_state(KEY_2))
	{
		count_beep=5;
//		angle=0;
//		set_val=8;
		shangdain=1;
		key_clear_state(KEY_2);	
	}
	else if(KEY_SHORT_PRESS == key_get_state(KEY_3))
	{
		count_beep=5;
		flg_confirmcorner=18;
//		shangdain=0;
		
		
		key_clear_state(KEY_3);
	}
	else if(KEY_SHORT_PRESS == key_get_state(KEY_4))
	{
		count_beep=5;
//		key_control_speed=4;
		start_transport=1;
//		gpio_set_level(C31, 1);
		key_clear_state(KEY_4);
	}
}