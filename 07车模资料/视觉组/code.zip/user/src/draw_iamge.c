#include "all_headfiles.h"

void draw_image1(uint8 image[120][188])
{	
	//�ȸ���ͼ��
	for(int i=0;i<119;i++)
	{
		for(int j=0;j<187;j++)
		{
			image[i][j]=mt9v03x_image[i][j];
		}
	}
		//������һȦ�ú�
		for(int j=0;j<187;j++)
		{
			image[0][j]=0;
			image[119][j]=0;
		}
			for(int i=0;i<119;i++)
		{
			image[i][0]=0;
			image[i][187]=0;
		}
}


void draw_line_for_cross(uint8 pst[120][188],int x1,int x2,int y1,int y2)
{
	for(int a=y1;a>=1;a--)
	{
		pst[a][x1]=0;
	}
	for(int a=y2;a>=1;a--)
	{
		pst[a][x2]=0;
	}
}