#include "all_headfiles.h"

float hezi[4]={-23,67,155,245};//��Ӧ����1��2��3��4
float servo1_duty,servo2_duty,servo3_duty=0;                                            			  // ��������Ƕ�
uint8 servo_over=0;
float servo1_angle,servo2_angle,servo3_angle;//˳��Ϊ���ӣ�С�ۣ����
float servo1_targe_angle,servo2_targe_angle,servo3_targe_angle;//˳��Ϊ���ӣ�С�ۣ����
int servo1_speed,servo2_speed,servo3_speed;//ʰȡ�ͷ��ÿ�Ƭ�������ٶ�

//�����ʼ��
void servo_init(void)
{
    pwm_init(SERVO_MOTOR1_PWM, SERVO_MOTOR_FREQ, 0);
    pwm_init(SERVO_MOTOR2_PWM, SERVO_MOTOR_FREQ, 0);
    pwm_init(SERVO_MOTOR3_PWM, SERVO_MOTOR_FREQ, 0);
	gpio_init(C31, GPO, 0, GPO_PUSH_PULL);
	gpio_set_level(C31, 0);
}
//�жϿ��ƶ������,hezi
float servo1_slow(float servo_angle1, float new_angle, uint16 angle_times)
{
	static float angle_start,delta_steps;
	static bool delta_over=1;
	static uint16 all_steps;
	if(delta_over)
	{
		delta_steps=(new_angle-servo_angle1)/angle_times;		
		all_steps = angle_times;								
		angle_start=servo_angle1;								
		delta_over=0;											
		return servo_angle1;
	}
	else
	{
		angle_start+=delta_steps;
		all_steps--;
		if(all_steps==0)
		{
			delta_over=1;
		}
		else
		{
			delta_over=0;
		}
		return angle_start;
	}
}
float servo2_slow(float servo_angle1, float new_angle, uint16 angle_times)
{
	static float angle_start,delta_steps;
	static bool delta_over=1;
	static uint16 all_steps;
	if(delta_over)
	{
		delta_steps=(new_angle-servo_angle1)/angle_times;		
		all_steps = angle_times;								
		angle_start=servo_angle1;								
		delta_over=0;											
		return servo_angle1;
	}
	else
	{
		angle_start+=delta_steps;
		all_steps--;
		if(all_steps==0)
		{
			delta_over=1;
		}
		else
		{
			delta_over=0;
		}
		return angle_start;
	}
}

float servo3_slow(float servo_angle1, float new_angle, uint16 angle_times)
{
	static float angle_start,delta_steps;
	static bool delta_over=1;
	static uint16 all_steps;
	if(delta_over)
	{
		delta_steps=(new_angle-servo_angle1)/angle_times;		
		all_steps = angle_times;								
		angle_start=servo_angle1;								
		delta_over=0;											
		return servo_angle1;
	}
	else
	{
		angle_start+=delta_steps;
		all_steps--;
		if(all_steps==0)
		{
			delta_over=1;
		}
		else
		{
			delta_over=0;
		}
		return angle_start;
	}
}


//ʰȡ��Ƭ
void take_card(uint8 cont,uint8 *flg)
{
	static int current_time=0;
	static uint8 jilu=0;
	static int ab_time=0;
	servo1_speed=250;
	servo2_speed=800;
	servo3_speed=100;
	if(*(flg)==1)
	{
		switch(cont)
			{
				case 1:		//�ŵ�1�ķ���
							servo1_targe_angle=-23;	
							break;
				case 2:		//�ŵ�2�ķ���
							servo1_targe_angle=67;
							break;
				case 3:		//�ŵ�3�ķ���
							servo1_targe_angle=155;
							break;
				case 4:		//�ŵ�4�ķ���
							servo1_targe_angle=245;
			}
		ips200_show_int(10,120,jilu,5);
		if(jilu==0)
		{
			gpio_set_level(C31, 1);
			current_time=count_ms;
			jilu=1;
		}
		ab_time=count_ms-current_time;
		if(jilu==1)
		{
			servo2_targe_angle=10;//��Ƭ
			servo3_targe_angle=16;
			
			jilu=2;
		}
		if(jilu==2&&ab_time>1000)
		{
			servo3_targe_angle=45;
			jilu=3;
		}
		if(ab_time>1500&&jilu==3)//�ſ�Ƭ
		{
			servo2_targe_angle=180;
			servo3_targe_angle=95;
			jilu=4;
		}
		if(ab_time>2000&&jilu==4)
		{
			servo2_targe_angle=192;
			servo3_targe_angle=98;
			jilu=5;
		}
		if((ab_time>3000)&&(jilu>=5))//����Ƭ����
		{
			
			//��λ
			gpio_set_level(C31, 0);
//			system_delay_ms(5000);

			servo2_targe_angle=5;
			servo3_targe_angle=105;
			jilu=6;
		}
		if(ab_time>4000&&jilu==6)//��λ
		{
			
			gpio_set_level(C31, 0);
			*(flg)=0;
			jilu=0;
			current_time=0;
			ab_time=0;
		}
	}
//	else
//	{
//	  gpio_set_level(C31, 0);
//	}
}
//ȡ��Ƭ
void fangkapian (uint8 cont,uint8 *flg)
{
	static int current_time=0;
	static uint8 jilu=0;
	static int ab_time=0;
	servo1_speed=500;
	servo2_speed=100;
	servo3_speed=200;
	//
	if(*(flg)==2)
	{
		switch(cont)
			{
				case 1:		//�ŵ�1�ķ���
							servo1_targe_angle=-23;	
							break;
				case 2:		//�ŵ�2�ķ���
							servo1_targe_angle=67;
							break;
				case 3:		//�ŵ�3�ķ���
							servo1_targe_angle=155;
							break;
				case 4:		//�ŵ�4�ķ���
							servo1_targe_angle=245;
			}
		ips200_show_int(10,20,ab_time,5);
		if(jilu==0)
		{
			current_time=count_ms;
			gpio_set_level(C31, 1);
			jilu=1;
		}
		ab_time=count_ms-current_time;
		if(jilu==1)
		{
			gpio_set_level(C31, 1);
			servo2_targe_angle=208;//ȡ��Ƭ,�ȶ�С��
			jilu=2;
		}
		if(jilu==2&&ab_time>900)//�ٶ����
		{
			servo3_targe_angle=104;
			jilu=3;
		}
		//�Ӻ�����ȡ����Ҳ���ȶ�С��//�ٶ����
		if(jilu==3&&ab_time>1200)
		{
			servo2_targe_angle=195;//ȡ��Ƭ,�ȶ�С��
			servo3_targe_angle=100;
			jilu=4;
		}
		if(jilu==4&&ab_time>1800)
		{
			servo2_targe_angle=185;//ȡ��Ƭ,�ȶ�С��
			servo3_targe_angle=95;
			jilu=5;
		}
		if(jilu==5&&ab_time>2100)
		{
			servo2_targe_angle=120;//ȡ��Ƭ,�ȶ�С��
			servo3_targe_angle=90;
			jilu=6;
		}
		if(jilu==6&&ab_time>2600)
		{
			servo2_targe_angle=30;//ȡ��Ƭ,�ȶ�С��
			servo3_targe_angle=45;
			jilu=7;
		}
		if(jilu==7&&ab_time>2850)
		{
			servo2_targe_angle=15;//ȡ��Ƭ,�ȶ�С��
			servo3_targe_angle=20;
			jilu=8;
		}
		if(jilu==8&&ab_time>3200)
		{
			gpio_set_level(C31, 0);
			jilu=9;
		}
		if(jilu==9&&ab_time>3300)
		{
			//��е�۸�λ
			servo2_targe_angle=5;
			servo3_targe_angle=100;
			jilu=10;
		}
		if(ab_time>3200&&jilu==10)//��λ
		{
			*(flg)=0;
			jilu=0;
			current_time=0;
			ab_time=0;
		}
	}
}

void control_servo_move(void)
{
		servo1_angle=servo1_slow(servo1_angle,servo1_targe_angle,servo1_speed);
		pwm_set_duty(SERVO_MOTOR3_PWM, (uint32)SERVO_MOTOR_DUTY_360(servo1_angle));//���ӵĶ��
		
		servo2_angle=servo2_slow(servo2_angle,servo2_targe_angle,servo2_speed);
		pwm_set_duty(SERVO_MOTOR1_PWM, (uint32)SERVO_MOTOR_DUTY_270(servo2_angle));//С��
		
		servo3_angle=servo3_slow(servo3_angle,servo3_targe_angle,servo3_speed);
		pwm_set_duty(SERVO_MOTOR2_PWM, (uint32)SERVO_MOTOR_DUTY_180(servo3_angle));//���
        pit_flag_clear(PIT_CH0);
}

void servo_reset(void)
{
	//��ʼ����Ƕ�//��λ�Ƕ�
	servo1_angle=hezi[0];//����1�Ǿ��Ǹ�λ�Ƕ�
	servo2_angle=10;//С�۶��10��������Ƭ�ĽǶ�,190�Ƿſ�Ƭ�ĽǶȣ�������Ƭ�Ƕȣ�210
	servo3_angle=100;//��۶��15��������Ƭ�ĽǶȣ���λ�Ƕ���100
	servo1_targe_angle=servo1_angle;
	servo2_targe_angle=servo2_angle;
	servo3_targe_angle=servo3_angle;
	pwm_set_duty(SERVO_MOTOR3_PWM, (uint32)SERVO_MOTOR_DUTY_360(servo1_angle));//���ӵĶ��
	pwm_set_duty(SERVO_MOTOR1_PWM, (uint32)SERVO_MOTOR_DUTY_270(servo2_angle));//С��
	pwm_set_duty(SERVO_MOTOR2_PWM, (uint32)SERVO_MOTOR_DUTY_180(servo3_angle));//���
}