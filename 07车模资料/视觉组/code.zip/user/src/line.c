#include "all_headfiles.h"

void fine_line_corner()
{
	/****************************
				����Ѳ��+��ʾ����
				*****************************/
				findline_lefthand_adaptive1(7,6,bx1,by1,ipts0,ipts0_num);
				for(int t=0;t<4;t++)
				{
					if(ipts0[t][0]==ipts0[t+4][0]&&ipts0[t][1]==ipts0[t+4][1])
					{
						bx1--;
						if(bx1==2)
						{
							bx1=2;
						}
					}
				}
				
				for(int i=0;i<step_0;i++)
				{	
					ips200_draw_point(ipts0[i][0]+5,ipts0[i][1],RGB565_RED);
				}
				/****************************
				����Ѳ��+��ʾ����
				*****************************/
				findline_righthand_adaptive1(7,6,bx2,by2,ipts1,ipts1_num);
				for(int t=0;t<4;t++)
				{
					if(ipts1[t][0]==ipts1[t+4][0]&&ipts1[t][1]==ipts1[t+4][1])
					{
						bx2--;
						if(bx1==2)
						{
							bx1=2;
						}
					}
				}
				for(int i=0;i<step_0;i++)
				{	
					ips200_draw_point(ipts1[i][0]-5,ipts1[i][1],RGB565_RED);
				}
				/****************************
				��������+��ʾ����
				*****************************/
				extract_middleline(ipts0,ipts1,middle_ipts);
				for(int i=0;i<step_0;i++)
				{	
					ips200_draw_point(middle_ipts[i][0],middle_ipts[i][1],RGB565_BLUE);
				}
				//�ҽǵ�
				mytest_left_korner(ipts0,ipts0_num1);
				mytest_right_korner(ipts1,ipts1_num1);
				//�����ƽǵ�
				if(corner0==1||corner1==1)//�����ƽǵ�
				{
					flg_findcorner=1;
				}
				confirm_corner();//ȷ�Ͻǵ�
}